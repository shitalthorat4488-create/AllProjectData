# Data Dictionary — INX Future Inc Employee Performance Dataset
**Project Code:** 10281

| Column | Type | Description | Values / Range |
|---|---|---|---|
| EmpNumber | String | Unique employee identifier | E.g. E1001000 |
| Age | Integer | Employee age in years | 18–60 |
| Gender | Categorical | Employee gender | Male, Female |
| EducationBackground | Categorical | Field of education | Human Resources, Life Sciences, Marketing, Medical, Other, Technical Degree |
| MaritalStatus | Categorical | Marital status | Single, Married, Divorced |
| EmpDepartment | Categorical | Department | Sales, Development, R&D, Human Resources, Finance, Data Science |
| EmpJobRole | Categorical | Job role title | 17 distinct roles |
| BusinessTravelFrequency | Categorical | Travel frequency | Non-Travel, Travel_Rarely, Travel_Frequently |
| DistanceFromHome | Integer | Commute distance (km) | 1–29 |
| EmpEducationLevel | Integer | Education level | 1 (Below College) to 5 (Doctor) |
| EmpEnvironmentSatisfaction | Integer | Workplace environment satisfaction | 1 (Low) to 4 (Very High) |
| EmpHourlyRate | Integer | Hourly pay rate | 30–100 |
| EmpJobInvolvement | Integer | Degree of job involvement | 1 (Low) to 4 (Very High) |
| EmpJobLevel | Integer | Job seniority level | 1 (Entry) to 5 (Executive) |
| EmpJobSatisfaction | Integer | Job satisfaction score | 1 (Low) to 4 (Very High) |
| NumCompaniesWorked | Integer | Previous employers count | 0–9 |
| OverTime | Categorical | Works overtime | Yes, No |
| EmpLastSalaryHikePercent | Integer | Last annual salary hike % | 11–25 |
| EmpRelationshipSatisfaction | Integer | Satisfaction with work relationships | 1 (Low) to 4 (Very High) |
| TotalWorkExperienceInYears | Integer | Total work experience (years) | 0–40 |
| TrainingTimesLastYear | Integer | Number of trainings in last year | 0–6 |
| EmpWorkLifeBalance | Integer | Work-life balance perception | 1 (Bad) to 4 (Best) |
| ExperienceYearsAtThisCompany | Integer | Years at INX | 0–40 |
| ExperienceYearsInCurrentRole | Integer | Years in current role | 0–18 |
| YearsSinceLastPromotion | Integer | Years since last promotion | 0–15 |
| YearsWithCurrManager | Integer | Years under current manager | 0–17 |
| Attrition | Categorical | Whether employee left the company | Yes, No |
| PerformanceRating | Integer | **Target variable** — performance rating | 2 (Low), 3 (Good), 4 (Excellent) |
