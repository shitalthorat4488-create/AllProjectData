"""
INX Future Inc — Employee Performance Analysis
Streamlit Web Application
Project Code: 10281

Run with:
    pip install streamlit plotly pandas scikit-learn openpyxl
    streamlit run app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import warnings
warnings.filterwarnings("ignore")

# ─── PAGE CONFIG ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="INX Employee Performance",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── CUSTOM CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main { background-color: #f8f9fa; }
    .metric-card {
        background: white;
        border-radius: 10px;
        padding: 1.2rem 1.5rem;
        border-left: 4px solid #2E75B6;
        box-shadow: 0 1px 4px rgba(0,0,0,0.07);
        margin-bottom: 0.5rem;
    }
    .metric-card.red  { border-left-color: #E24B4A; }
    .metric-card.green{ border-left-color: #639922; }
    .metric-card.amber{ border-left-color: #EF9F27; }
    .metric-label { font-size: 12px; color: #6c757d; margin-bottom: 2px; }
    .metric-value { font-size: 28px; font-weight: 600; color: #1F3864; }
    .metric-sub   { font-size: 12px; color: #9ca3af; }
    .section-header {
        font-size: 20px; font-weight: 600; color: #1F3864;
        border-bottom: 2px solid #2E75B6;
        padding-bottom: 6px; margin-bottom: 1rem;
    }
    .insight-box {
        background: #EBF4FF;
        border-left: 3px solid #2E75B6;
        border-radius: 0 8px 8px 0;
        padding: 10px 14px;
        margin: 6px 0;
        font-size: 14px;
        color: #1F3864;
    }
    .stSelectbox label, .stSlider label, .stRadio label { font-weight: 500; }
</style>
""", unsafe_allow_html=True)

# ─── DATA LOADING & MODEL TRAINING ────────────────────────────────────────────
@st.cache_data
def load_data(uploaded_file=None):
    if uploaded_file is not None:
        return pd.read_excel(uploaded_file)
    # Try default path (works if app.py is inside the project folder)
    for path in [
        "data/raw/INX_Future_Inc_Employee_Performance.xlsx",
        "INX_Future_Inc_Employee_Performance.xlsx",
        "INX_Project/data/raw/INX_Future_Inc_Employee_Performance.xlsx",
    ]:
        try:
            return pd.read_excel(path)
        except FileNotFoundError:
            continue
    return None


@st.cache_resource
def train_model(df):
    df_enc = df.copy()
    cat_cols = ["Gender", "EducationBackground", "MaritalStatus",
                "EmpDepartment", "EmpJobRole", "BusinessTravelFrequency",
                "OverTime", "Attrition"]
    le = LabelEncoder()
    for c in cat_cols:
        df_enc[c] = le.fit_transform(df_enc[c].astype(str))
    features = [c for c in df_enc.columns if c not in ["EmpNumber", "PerformanceRating"]]
    X = df_enc[features]
    y = df_enc["PerformanceRating"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)
    rf = RandomForestClassifier(n_estimators=200, class_weight="balanced", random_state=42)
    rf.fit(X_train, y_train)
    acc = accuracy_score(y_test, rf.predict(X_test))
    return rf, features, acc


# ─── ENCODING MAPS (mirror the training encoding) ─────────────────────────────
ENCODE = {
    "Gender":                  {"Male": 1, "Female": 0},
    "OverTime":                {"Yes": 1, "No": 0},
    "Attrition":               {"Yes": 1, "No": 0},
    "BusinessTravelFrequency": {"Non-Travel": 0, "Travel_Rarely": 1, "Travel_Frequently": 2},
    "EducationBackground":     {"Human Resources": 0, "Life Sciences": 1, "Marketing": 2,
                                "Medical": 3, "Other": 4, "Technical Degree": 5},
    "MaritalStatus":           {"Divorced": 0, "Married": 1, "Single": 2},
    "EmpDepartment":           {"Data Science": 0, "Development": 1, "Finance": 2,
                                "Human Resources": 3, "Research & Development": 4, "Sales": 5},
    "EmpJobRole":              {"Business Analyst": 0, "Data Scientist": 1, "Delivery Manager": 2,
                                "Developer": 3, "Finance Manager": 4, "HR": 5,
                                "Manager": 6, "Manager R&D": 7, "Manufacturing Director": 8,
                                "Research Director": 9, "Research Scientist": 10,
                                "Sales Executive": 11, "Sales Representative": 12,
                                "Senior Developer": 13, "Senior Manager R&D": 14,
                                "Technical Architect": 15, "Technical Lead": 16},
}

COLORS = {"Low (2)": "#E24B4A", "Good (3)": "#378ADD", "Excellent (4)": "#639922"}
DEPT_COLORS = px.colors.qualitative.Set2

# ─── SIDEBAR ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image("https://via.placeholder.com/280x60/1F3864/FFFFFF?text=INX+Future+Inc",
             use_container_width=True)
    st.markdown("### 📂 Data Source")
    uploaded = st.file_uploader("Upload INX dataset (.xlsx)", type=["xlsx", "xls"])
    st.markdown("---")
    st.markdown("### 🗂 Navigation")
    page = st.radio("", [
        "📊  Dashboard",
        "🏢  Department Analysis",
        "🔬  Feature Insights",
        "🤖  Performance Predictor",
        "📋  Model Report",
    ], label_visibility="collapsed")
    st.markdown("---")
    st.caption("Project Code: 10281  |  IABAC™ CDS")

# ─── LOAD DATA ────────────────────────────────────────────────────────────────
df_raw = load_data(uploaded)

if df_raw is None:
    st.warning("⚠️ Dataset not found. Please upload the INX Excel file using the sidebar.")
    st.info("Expected file: `INX_Future_Inc_Employee_Performance.xlsx`")
    st.stop()

df = df_raw.copy()
model, feature_cols, model_acc = train_model(df)

# ─── HELPERS ──────────────────────────────────────────────────────────────────
def rating_label(r):
    return {2: "Low (2)", 3: "Good (3)", 4: "Excellent (4)"}.get(r, str(r))

df["RatingLabel"] = df["PerformanceRating"].map(rating_label)

# ══════════════════════════════════════════════════════════════════════════════
# PAGE 1 — DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════
if page == "📊  Dashboard":
    st.markdown("## 📊 Employee Performance Dashboard")
    st.markdown("**INX Future Inc  |  1,200 Employees  |  6 Departments**")
    st.markdown("---")

    # KPI row
    total   = len(df)
    low_n   = (df["PerformanceRating"] == 2).sum()
    good_n  = (df["PerformanceRating"] == 3).sum()
    high_n  = (df["PerformanceRating"] == 4).sum()
    avg_env = df["EmpEnvironmentSatisfaction"].mean()

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.markdown(f'<div class="metric-card"><div class="metric-label">Total Employees</div>'
                f'<div class="metric-value">{total:,}</div>'
                f'<div class="metric-sub">6 departments</div></div>', unsafe_allow_html=True)
    c2.markdown(f'<div class="metric-card red"><div class="metric-label">Low Performers</div>'
                f'<div class="metric-value">{low_n}</div>'
                f'<div class="metric-sub">{low_n/total*100:.1f}% of workforce</div></div>', unsafe_allow_html=True)
    c3.markdown(f'<div class="metric-card"><div class="metric-label">Good Performers</div>'
                f'<div class="metric-value">{good_n}</div>'
                f'<div class="metric-sub">{good_n/total*100:.1f}% of workforce</div></div>', unsafe_allow_html=True)
    c4.markdown(f'<div class="metric-card green"><div class="metric-label">Excellent Performers</div>'
                f'<div class="metric-value">{high_n}</div>'
                f'<div class="metric-sub">{high_n/total*100:.1f}% of workforce</div></div>', unsafe_allow_html=True)
    c5.markdown(f'<div class="metric-card amber"><div class="metric-label">Model Accuracy</div>'
                f'<div class="metric-value">{model_acc*100:.1f}%</div>'
                f'<div class="metric-sub">Random Forest</div></div>', unsafe_allow_html=True)

    st.markdown("---")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="section-header">Performance Rating Distribution</div>', unsafe_allow_html=True)
        rating_counts = df["RatingLabel"].value_counts().reset_index()
        rating_counts.columns = ["Rating", "Count"]
        fig = px.pie(rating_counts, values="Count", names="Rating",
                     color="Rating", color_discrete_map=COLORS,
                     hole=0.45)
        fig.update_traces(textposition="outside", textinfo="percent+label")
        fig.update_layout(showlegend=False, margin=dict(t=10, b=10, l=10, r=10), height=300)
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.markdown('<div class="section-header">Department Headcount</div>', unsafe_allow_html=True)
        dept_counts = df["EmpDepartment"].value_counts().reset_index()
        dept_counts.columns = ["Department", "Count"]
        fig2 = px.bar(dept_counts, x="Count", y="Department", orientation="h",
                      color="Department", color_discrete_sequence=DEPT_COLORS,
                      text="Count")
        fig2.update_traces(textposition="outside")
        fig2.update_layout(showlegend=False, margin=dict(t=10, b=10, l=10, r=10),
                           height=300, yaxis_title="", xaxis_title="Employees")
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Key Performance Drivers — Quick View</div>', unsafe_allow_html=True)

    col3, col4, col5 = st.columns(3)

    with col3:
        env_avg = df.groupby("PerformanceRating")["EmpEnvironmentSatisfaction"].mean().reset_index()
        env_avg["RatingLabel"] = env_avg["PerformanceRating"].map(rating_label)
        fig3 = px.bar(env_avg, x="RatingLabel", y="EmpEnvironmentSatisfaction",
                      color="RatingLabel", color_discrete_map=COLORS,
                      title="Avg Environment Satisfaction", text=env_avg["EmpEnvironmentSatisfaction"].round(2))
        fig3.update_traces(textposition="outside")
        fig3.update_layout(showlegend=False, height=280, margin=dict(t=40,b=10,l=10,r=10),
                           yaxis=dict(range=[0, 4.3]), xaxis_title="", yaxis_title="Score (1–4)")
        st.plotly_chart(fig3, use_container_width=True)

    with col4:
        hike_avg = df.groupby("PerformanceRating")["EmpLastSalaryHikePercent"].mean().reset_index()
        hike_avg["RatingLabel"] = hike_avg["PerformanceRating"].map(rating_label)
        fig4 = px.bar(hike_avg, x="RatingLabel", y="EmpLastSalaryHikePercent",
                      color="RatingLabel", color_discrete_map=COLORS,
                      title="Avg Salary Hike %", text=hike_avg["EmpLastSalaryHikePercent"].round(1))
        fig4.update_traces(textposition="outside", texttemplate="%{text}%")
        fig4.update_layout(showlegend=False, height=280, margin=dict(t=40,b=10,l=10,r=10),
                           yaxis=dict(range=[12, 23]), xaxis_title="", yaxis_title="Hike %")
        st.plotly_chart(fig4, use_container_width=True)

    with col5:
        promo_avg = df.groupby("PerformanceRating")["YearsSinceLastPromotion"].mean().reset_index()
        promo_avg["RatingLabel"] = promo_avg["PerformanceRating"].map(rating_label)
        fig5 = px.bar(promo_avg, x="RatingLabel", y="YearsSinceLastPromotion",
                      color="RatingLabel", color_discrete_map=COLORS,
                      title="Avg Years Since Promotion", text=promo_avg["YearsSinceLastPromotion"].round(1))
        fig5.update_traces(textposition="outside", texttemplate="%{text} yrs")
        fig5.update_layout(showlegend=False, height=280, margin=dict(t=40,b=10,l=10,r=10),
                           xaxis_title="", yaxis_title="Years")
        st.plotly_chart(fig5, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 2 — DEPARTMENT ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🏢  Department Analysis":
    st.markdown("## 🏢 Department-wise Performance Analysis")
    st.markdown("---")

    dept_stats = df.groupby("EmpDepartment").agg(
        AvgRating=("PerformanceRating", "mean"),
        Count=("PerformanceRating", "count")
    ).reset_index()
    dept_stats["LowPct"]  = df[df["PerformanceRating"] <= 2].groupby("EmpDepartment").size().reindex(dept_stats["EmpDepartment"]).fillna(0).values / dept_stats["Count"] * 100
    dept_stats["HighPct"] = df[df["PerformanceRating"] == 4].groupby("EmpDepartment").size().reindex(dept_stats["EmpDepartment"]).fillna(0).values / dept_stats["Count"] * 100
    dept_stats = dept_stats.sort_values("AvgRating", ascending=False)

    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="section-header">Average Performance Rating</div>', unsafe_allow_html=True)
        fig = px.bar(dept_stats, x="AvgRating", y="EmpDepartment", orientation="h",
                     color="AvgRating", color_continuous_scale=["#E24B4A", "#EF9F27", "#639922"],
                     range_color=[2.7, 3.2], text=dept_stats["AvgRating"].round(3))
        fig.update_traces(textposition="outside")
        fig.add_vline(x=3.0, line_dash="dash", line_color="gray", annotation_text="Score = 3")
        fig.update_layout(coloraxis_showscale=False, height=320, margin=dict(t=10,b=10,l=10,r=80),
                          yaxis_title="", xaxis=dict(range=[2.5, 3.3]))
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.markdown('<div class="section-header">Low vs High Performer %</div>', unsafe_allow_html=True)
        fig2 = go.Figure()
        fig2.add_trace(go.Bar(name="Low Performers %", x=dept_stats["EmpDepartment"],
                               y=dept_stats["LowPct"], marker_color="#E24B4A",
                               text=dept_stats["LowPct"].round(1), texttemplate="%{text}%",
                               textposition="outside"))
        fig2.add_trace(go.Bar(name="High Performers %", x=dept_stats["EmpDepartment"],
                               y=dept_stats["HighPct"], marker_color="#639922",
                               text=dept_stats["HighPct"].round(1), texttemplate="%{text}%",
                               textposition="outside"))
        fig2.update_layout(barmode="group", height=320,
                           margin=dict(t=10,b=10,l=10,r=10),
                           legend=dict(orientation="h", yanchor="bottom", y=1.02))
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Department Risk Map</div>', unsafe_allow_html=True)

    fig3 = px.scatter(dept_stats,
                      x="LowPct", y="AvgRating",
                      size="Count", color="EmpDepartment",
                      text="EmpDepartment",
                      color_discrete_sequence=DEPT_COLORS,
                      size_max=60,
                      labels={"LowPct": "Low Performer Rate (%)", "AvgRating": "Avg Performance Rating"})
    fig3.add_hline(y=3.0, line_dash="dash", line_color="gray", annotation_text="Rating = 3 baseline")
    fig3.add_vline(x=15, line_dash="dash", line_color="#E24B4A", opacity=0.4,
                   annotation_text="High-risk threshold")
    fig3.update_traces(textposition="top center")
    fig3.update_layout(showlegend=False, height=400, margin=dict(t=20,b=20,l=20,r=20))
    st.plotly_chart(fig3, use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Department Summary Table</div>', unsafe_allow_html=True)

    display_df = dept_stats.copy()
    display_df["AvgRating"] = display_df["AvgRating"].round(3)
    display_df["LowPct"]    = display_df["LowPct"].round(1).astype(str) + "%"
    display_df["HighPct"]   = display_df["HighPct"].round(1).astype(str) + "%"
    display_df.columns      = ["Department", "Avg Rating", "Headcount", "Low Performer %", "High Performer %"]
    st.dataframe(display_df.set_index("Department"), use_container_width=True)

    st.markdown('<div class="insight-box">💡 <b>Finance</b> has the highest low-performer rate at 30.6% and lowest average rating (2.776) — an immediate intervention priority.</div>', unsafe_allow_html=True)
    st.markdown('<div class="insight-box">💡 <b>Development</b> leads with only 3.6% low performers and an average rating of 3.086.</div>', unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 3 — FEATURE INSIGHTS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🔬  Feature Insights":
    st.markdown("## 🔬 Feature Insights")
    st.markdown("---")

    # Feature importance
    st.markdown('<div class="section-header">Top 15 Feature Importances — Random Forest</div>', unsafe_allow_html=True)
    feat_imp = pd.Series(model.feature_importances_, index=feature_cols).sort_values(ascending=True).tail(15)
    fig = px.bar(feat_imp, orientation="h",
                 color=feat_imp.values,
                 color_continuous_scale=["#B5D4F4", "#378ADD", "#1F3864"],
                 text=feat_imp.round(4))
    fig.update_traces(texttemplate="%{text:.3f}", textposition="outside")
    fig.update_layout(coloraxis_showscale=False, height=450,
                      margin=dict(t=10,b=10,l=10,r=80),
                      xaxis_title="Importance Score", yaxis_title="")
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Explore Any Feature vs Performance Rating</div>', unsafe_allow_html=True)

    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    numeric_cols = [c for c in numeric_cols if c != "PerformanceRating"]

    selected_feature = st.selectbox("Select a feature to analyse:", numeric_cols,
                                    index=numeric_cols.index("EmpEnvironmentSatisfaction") if "EmpEnvironmentSatisfaction" in numeric_cols else 0)

    col1, col2 = st.columns(2)

    with col1:
        avg_by_rating = df.groupby("PerformanceRating")[selected_feature].mean().reset_index()
        avg_by_rating["RatingLabel"] = avg_by_rating["PerformanceRating"].map(rating_label)
        fig2 = px.bar(avg_by_rating, x="RatingLabel", y=selected_feature,
                      color="RatingLabel", color_discrete_map=COLORS,
                      title=f"Avg {selected_feature} by Performance Rating",
                      text=avg_by_rating[selected_feature].round(2))
        fig2.update_traces(textposition="outside")
        fig2.update_layout(showlegend=False, height=350, margin=dict(t=40,b=10,l=10,r=10),
                           xaxis_title="", yaxis_title=selected_feature)
        st.plotly_chart(fig2, use_container_width=True)

    with col2:
        fig3 = px.box(df, x="RatingLabel", y=selected_feature,
                      color="RatingLabel", color_discrete_map=COLORS,
                      title=f"{selected_feature} Distribution by Rating",
                      category_orders={"RatingLabel": ["Low (2)", "Good (3)", "Excellent (4)"]})
        fig3.update_layout(showlegend=False, height=350, margin=dict(t=40,b=10,l=10,r=10),
                           xaxis_title="", yaxis_title=selected_feature)
        st.plotly_chart(fig3, use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Correlation Heatmap</div>', unsafe_allow_html=True)

    top_features = pd.Series(model.feature_importances_, index=feature_cols).nlargest(12).index.tolist()
    corr_data = df[top_features + ["PerformanceRating"]].corr()
    fig4 = px.imshow(corr_data, text_auto=".2f", color_continuous_scale="RdBu_r",
                     zmin=-1, zmax=1, aspect="auto", height=500)
    fig4.update_layout(margin=dict(t=10,b=10,l=10,r=10))
    st.plotly_chart(fig4, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 4 — PERFORMANCE PREDICTOR
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🤖  Performance Predictor":
    st.markdown("## 🤖 Employee Performance Predictor")
    st.markdown("Fill in the employee profile below to predict their performance rating.")
    st.markdown("---")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("**Personal Information**")
        age            = st.slider("Age", 18, 60, 32)
        gender         = st.selectbox("Gender", ["Male", "Female"])
        marital_status = st.selectbox("Marital Status", ["Single", "Married", "Divorced"])
        edu_bg         = st.selectbox("Education Background",
                                      ["Life Sciences", "Medical", "Marketing",
                                       "Technical Degree", "Human Resources", "Other"])
        edu_level      = st.slider("Education Level (1=Below College, 5=Doctor)", 1, 5, 3)
        distance       = st.slider("Distance from Home (km)", 1, 30, 10)

    with col2:
        st.markdown("**Job Information**")
        department     = st.selectbox("Department",
                                      ["Sales", "Development", "Research & Development",
                                       "Human Resources", "Finance", "Data Science"])
        job_role       = st.selectbox("Job Role",
                                      ["Sales Executive", "Developer", "Research Scientist",
                                       "Senior Developer", "Technical Lead", "Data Scientist",
                                       "Finance Manager", "HR", "Manager", "Business Analyst",
                                       "Technical Architect", "Sales Representative",
                                       "Delivery Manager", "Manager R&D", "Senior Manager R&D",
                                       "Research Director", "Manufacturing Director"])
        job_level      = st.slider("Job Level (1=Entry, 5=Executive)", 1, 5, 2)
        travel         = st.selectbox("Business Travel", ["Travel_Rarely", "Non-Travel", "Travel_Frequently"])
        overtime       = st.selectbox("Works Overtime", ["No", "Yes"])
        num_companies  = st.slider("Number of Companies Worked", 0, 9, 2)

    with col3:
        st.markdown("**Satisfaction & Compensation**")
        env_sat        = st.slider("Environment Satisfaction (1=Low, 4=High)", 1, 4, 3)
        job_sat        = st.slider("Job Satisfaction (1=Low, 4=High)", 1, 4, 3)
        rel_sat        = st.slider("Relationship Satisfaction (1=Low, 4=High)", 1, 4, 3)
        wlb            = st.slider("Work-Life Balance (1=Bad, 4=Best)", 1, 4, 3)
        job_inv        = st.slider("Job Involvement (1=Low, 4=High)", 1, 4, 3)
        hourly_rate    = st.slider("Hourly Rate", 30, 100, 60)
        salary_hike    = st.slider("Last Salary Hike %", 11, 25, 15)

    st.markdown("---")
    col_exp1, col_exp2 = st.columns(2)
    with col_exp1:
        st.markdown("**Experience & Tenure**")
        total_exp      = st.slider("Total Work Experience (years)", 0, 40, 8)
        company_exp    = st.slider("Years at This Company", 0, 40, 5)
        role_exp       = st.slider("Years in Current Role", 0, 18, 3)
        years_promo    = st.slider("Years Since Last Promotion", 0, 15, 1)
        years_manager  = st.slider("Years with Current Manager", 0, 17, 2)
        training       = st.slider("Training Sessions Last Year", 0, 6, 2)
    with col_exp2:
        st.markdown("**Attrition Risk**")
        attrition      = st.selectbox("Attrition (Has employee left?)", ["No", "Yes"])

    st.markdown("---")

    if st.button("🔮  Predict Performance Rating", use_container_width=True):
        input_dict = {
            "Age": age, "Gender": ENCODE["Gender"][gender],
            "EducationBackground": ENCODE["EducationBackground"][edu_bg],
            "MaritalStatus": ENCODE["MaritalStatus"][marital_status],
            "EmpDepartment": ENCODE["EmpDepartment"][department],
            "EmpJobRole": ENCODE["EmpJobRole"].get(job_role, 0),
            "BusinessTravelFrequency": ENCODE["BusinessTravelFrequency"][travel],
            "DistanceFromHome": distance,
            "EmpEducationLevel": edu_level,
            "EmpEnvironmentSatisfaction": env_sat,
            "EmpHourlyRate": hourly_rate,
            "EmpJobInvolvement": job_inv,
            "EmpJobLevel": job_level,
            "EmpJobSatisfaction": job_sat,
            "NumCompaniesWorked": num_companies,
            "OverTime": ENCODE["OverTime"][overtime],
            "EmpLastSalaryHikePercent": salary_hike,
            "EmpRelationshipSatisfaction": rel_sat,
            "TotalWorkExperienceInYears": total_exp,
            "TrainingTimesLastYear": training,
            "EmpWorkLifeBalance": wlb,
            "ExperienceYearsAtThisCompany": company_exp,
            "ExperienceYearsInCurrentRole": role_exp,
            "YearsSinceLastPromotion": years_promo,
            "YearsWithCurrManager": years_manager,
            "Attrition": ENCODE["Attrition"][attrition],
        }

        input_df   = pd.DataFrame([input_dict])[feature_cols]
        prediction = model.predict(input_df)[0]
        probas     = model.predict_proba(input_df)[0]
        classes    = model.classes_

        RATING_META = {
            2: ("🔴", "Low Performer", "#E24B4A", "This employee profile is at risk. Focus on environment satisfaction and career development."),
            3: ("🔵", "Good Performer", "#378ADD", "This employee profile indicates consistent good performance. Monitor for promotion opportunities."),
            4: ("🟢", "Excellent Performer", "#639922", "This employee profile predicts excellent performance. Prioritise in hiring and retention."),
        }

        icon, label, color, advice = RATING_META[prediction]
        st.markdown(f"""
        <div style="background:{color}15; border:2px solid {color}; border-radius:12px; padding:1.5rem; text-align:center; margin:1rem 0;">
            <div style="font-size:48px;">{icon}</div>
            <div style="font-size:28px; font-weight:700; color:{color};">Predicted Rating: {prediction} — {label}</div>
            <div style="font-size:15px; color:#444; margin-top:8px;">{advice}</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("#### Confidence Scores")
        conf_cols = st.columns(len(classes))
        for i, (cls, prob) in enumerate(zip(classes, probas)):
            _, lbl, col, _ = RATING_META[cls]
            conf_cols[i].markdown(f"""
            <div style="background:white; border-radius:10px; padding:1rem; text-align:center;
                        border:1px solid {col}; box-shadow:0 1px 4px rgba(0,0,0,0.07);">
                <div style="font-size:13px; color:#6c757d;">{lbl}</div>
                <div style="font-size:32px; font-weight:700; color:{col};">{prob*100:.1f}%</div>
            </div>""", unsafe_allow_html=True)

        fig = go.Figure(go.Bar(
            x=[rating_label(c) for c in classes],
            y=[p * 100 for p in probas],
            marker_color=[RATING_META[c][2] for c in classes],
            text=[f"{p*100:.1f}%" for p in probas],
            textposition="outside"
        ))
        fig.update_layout(height=280, yaxis=dict(range=[0, 110], title="Probability (%)"),
                          margin=dict(t=20,b=10,l=10,r=10), xaxis_title="Performance Rating")
        st.plotly_chart(fig, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 5 — MODEL REPORT
# ══════════════════════════════════════════════════════════════════════════════
elif page == "📋  Model Report":
    st.markdown("## 📋 Model Report")
    st.markdown("---")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="section-header">Model Configuration</div>', unsafe_allow_html=True)
        config = {
            "Algorithm":          "Random Forest Classifier",
            "Number of Trees":    "200 estimators",
            "Class Weight":       "balanced (handles imbalance)",
            "Random State":       "42",
            "Train/Test Split":   "80% / 20% (stratified)",
            "Cross-Validation":   "5-fold GridSearchCV",
            "Test Accuracy":      f"{model_acc*100:.2f}%",
            "Top Feature":        "EmpEnvironmentSatisfaction (21.6%)",
        }
        for k, v in config.items():
            st.markdown(f"**{k}:** {v}")

    with col2:
        st.markdown('<div class="section-header">Class Distribution</div>', unsafe_allow_html=True)
        dist = df["RatingLabel"].value_counts().reset_index()
        dist.columns = ["Rating", "Count"]
        dist["Percentage"] = (dist["Count"] / len(df) * 100).round(1)
        fig = px.bar(dist, x="Rating", y="Count", color="Rating",
                     color_discrete_map=COLORS, text="Count")
        fig.update_traces(textposition="outside")
        fig.update_layout(showlegend=False, height=300, margin=dict(t=10,b=10,l=10,r=10))
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Performance Rating Breakdown by Department (Heatmap)</div>', unsafe_allow_html=True)

    heat_data = df.groupby(["EmpDepartment", "PerformanceRating"]).size().unstack(fill_value=0)
    heat_pct = (heat_data.div(heat_data.sum(axis=1), axis=0) * 100).round(1)
    heat_pct.columns = [rating_label(c) for c in heat_pct.columns]

    fig2 = px.imshow(heat_pct, text_auto=".1f", color_continuous_scale="Blues",
                     labels={"color": "%"}, aspect="auto", height=300)
    fig2.update_layout(margin=dict(t=10,b=10,l=10,r=10),
                       xaxis_title="Performance Rating", yaxis_title="Department")
    st.plotly_chart(fig2, use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Top 5 Recommendations</div>', unsafe_allow_html=True)

    recs = [
        ("🏢", "Improve workplace environment", "Critical",
         "Finance, Sales & R&D have the highest low-performer rates. Environment satisfaction is the #1 predictor (21.6% importance)."),
        ("📈", "Reform promotion cadence", "High",
         "Low performers average 3.70 years since last promotion — nearly double good performers. Implement 18–24 month career reviews."),
        ("💰", "Widen salary hike differential", "High",
         "Low and average performers receive nearly identical hikes (15.1% vs 14.4%). Widen the gap to create meaningful incentives."),
        ("🤖", "Deploy model in hiring", "Medium",
         "The 95% accurate Random Forest model should be used in recruitment to predict candidate performance before hiring decisions."),
        ("🚨", "Targeted Finance intervention", "Immediate",
         "30.6% low performers in Finance requires a dedicated management audit, not just a general programme rollout."),
    ]

    for icon, title, priority, desc in recs:
        p_color = {"Immediate": "#E24B4A", "Critical": "#E24B4A", "High": "#EF9F27", "Medium": "#378ADD"}[priority]
        st.markdown(f"""
        <div style="background:white; border-radius:10px; padding:1rem 1.25rem; margin:0.5rem 0;
                    border-left:4px solid {p_color}; box-shadow:0 1px 4px rgba(0,0,0,0.06);">
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:4px;">
                <span style="font-size:20px;">{icon}</span>
                <span style="font-weight:600; font-size:15px; color:#1F3864;">{title}</span>
                <span style="background:{p_color}20; color:{p_color}; border-radius:12px;
                             padding:2px 10px; font-size:12px; font-weight:600;">{priority}</span>
            </div>
            <div style="font-size:13px; color:#444; padding-left:30px;">{desc}</div>
        </div>
        """, unsafe_allow_html=True)