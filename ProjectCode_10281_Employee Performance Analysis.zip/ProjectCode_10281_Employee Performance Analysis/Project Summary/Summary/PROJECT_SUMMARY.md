# INX Future Inc — Employee Performance Analysis
## Project Summary
**Project Code:** 10281 | **IABAC™ Certified Data Scientist Project**

---

## 1. Project Overview

INX Future Inc is a leading data analytics and automation solutions provider with over 15 years of global presence. Despite being consistently rated among the top 20 best employers, employee performance has declined in recent years, resulting in increased service delivery escalations and an 8 percentage-point drop in client satisfaction. This project was commissioned by CEO Mr. Brain to identify the root causes of performance issues and build a predictive model to guide hiring and HR decisions.

---

## 2. Dataset

- **Source:** INX Future Inc HR Records
- **Records:** 1,200 employees
- **Features:** 28 (27 input features + 1 target)
- **Target:** `PerformanceRating` (scale: 2 = Low, 3 = Good, 4 = Excellent)
- **Class distribution:** 72.8% rated 3, 16.2% rated 2, 11.0% rated 4

---

## 3. Project Summary (Per IABAC Section 3)

### Algorithm and Training Method
A **Random Forest Classifier** (200 estimators, `class_weight='balanced'`) was selected as the final model after comparing four algorithms:

| Model | Test Accuracy |
|---|---|
| Random Forest (tuned) | **95.0%** |
| Gradient Boosting | 94.2% |
| Decision Tree | 88.5% |
| Logistic Regression | 72.3% |

Random Forest was chosen for its superior accuracy, robustness to outliers, resistance to overfitting (via bagging), and built-in feature importance scores. Hyperparameters were tuned via 5-fold GridSearchCV.

### Most Important Features
1. **Employee Environment Satisfaction** — 21.6% importance
2. **Employee Last Salary Hike %** — 21.1% importance
3. **Years Since Last Promotion** — 9.1% importance

These three features alone account for over 50% of predictive power.

### Other Techniques Used
- `LabelEncoder` and ordinal encoding for categorical features
- `StandardScaler` for Logistic Regression inputs
- Stratified train/test split (80/20) to preserve class ratios
- `class_weight='balanced'` to handle class imbalance

---

## 4. Feature Selection / Engineering (Per IABAC Section 4)

### Selected Features
All 27 input features were initially retained. The Random Forest model confirmed that `EmpEnvironmentSatisfaction`, `EmpLastSalaryHikePercent`, and `YearsSinceLastPromotion` are the most important predictors.

The non-predictive identifier column `EmpNumber` was dropped prior to modelling.

### Feature Transformations
- **Binary encoding:** Gender, OverTime, Attrition (Yes/No → 1/0)
- **Ordinal encoding:** BusinessTravelFrequency (Non-Travel=0, Travel_Rarely=1, Travel_Frequently=2)
- **Label encoding:** EducationBackground, MaritalStatus, EmpDepartment, EmpJobRole

### Correlations
`ExperienceYearsAtThisCompany` and `ExperienceYearsInCurrentRole` showed moderate correlation (r ≈ 0.63) with each other, but both were retained as they contribute uniquely to the model. No feature was dropped solely on correlation grounds, as Random Forest is inherently robust to multicollinearity through the random feature selection at each split.

---

## 5. Results, Analysis and Insights (Per IABAC Section 5)

### Department-Wise Performance

| Department | Avg Rating | Low Performer % | High Performer % |
|---|---|---|---|
| Development | 3.086 | 3.6% | 12.2% |
| Data Science | 3.050 | 5.0% | 10.0% |
| Human Resources | 2.926 | 18.5% | 11.1% |
| Research & Development | 2.921 | 19.8% | 12.0% |
| Sales | 2.861 | 23.3% | 9.4% |
| **Finance** | **2.776** | **30.6%** | **8.2%** |

**Finance is the highest-priority intervention target**, with 30.6% low performers and the lowest average rating across all departments.

### Answers to Business Problems

**1. Department-wise performances:**
Development and Data Science are the highest-performing departments. Finance, Sales, and R&D require immediate management attention due to high low-performer concentrations.

**2. Top 3 factors affecting performance:**
- **Environment Satisfaction:** Low performers score 1.58 avg vs 3.08 for excellent performers. 93% of all low-rated employees have satisfaction ≤ 2.
- **Last Salary Hike %:** High performers receive 20.7% hikes vs 15.1% for low performers. The gap between average and low performers is negligible (14.4% vs 15.1%) — insufficient to drive behaviour change.
- **Years Since Last Promotion:** Low performers average 3.70 years since last promotion, nearly double the 1.91 years seen in good/excellent performers.

**3. Trained predictive model:**
A Random Forest model achieving **95% test accuracy** has been trained, saved, and packaged with a prediction function (see `src/models/predict_model.ipynb`). HR can input candidate profile data to receive a predicted performance rating and confidence score before making a hire.

**4. Additional insights:**
- Work-life balance score averages 2.99 for excellent vs 2.63 for low performers — suggesting policies that protect personal time improve performance.
- Overtime is associated with increased low performer rates — forced overtime may reflect poor task allocation or poor management rather than dedication.
- Employees with low job satisfaction scores (1–2) predominantly fall in the low-performer category.

### Recommendations

1. **Improve workplace environment** — particularly in Finance, Sales, and R&D. Launch an environment survey and act on findings within a quarterly cycle.
2. **Reform promotion cadence** — implement structured career reviews every 18–24 months to prevent the stagnation pattern observed in low performers.
3. **Widen the salary hike differential** — the gap between average and low performers (14.4% vs 15.1%) needs widening to ~10–11 percentage points to create meaningful incentive signals.
4. **Deploy the predictive model in hiring** — use the trained model to screen candidates and predict performance tier before hire decisions.
5. **Target Finance department urgently** — with 30.6% low performers, Finance requires an immediate management audit and intervention plan.

---

## 6. Directory Structure

```
INX_Project/
├── Project Summary/
│   ├── Requirement/        ← Project brief and data description
│   ├── Analysis/           ← EDA findings and model comparison
│   └── Summary/            ← This document
├── data/
│   ├── raw/                ← Original INX employee performance dataset
│   ├── processed/          ← Encoded and cleaned dataset (CSV)
│   └── external/           ← (Reserved for supplementary data)
├── src/
│   ├── Data_Processing/
│   │   ├── data_processing.ipynb
│   │   └── data_exploratory_analysis.ipynb
│   ├── models/
│   │   ├── train_model.ipynb
│   │   ├── predict_model.ipynb
│   │   ├── random_forest_model.pkl
│   │   ├── scaler.pkl
│   │   └── feature_columns.pkl
│   └── visualization/
│       └── visualize.ipynb
└── references/
    └── data_dictionary.md
```

---

*Submitted in fulfilment of IABAC™ Certified Data Scientist Project Requirements. Project Code: 10281.*
